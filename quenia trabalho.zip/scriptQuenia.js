const fs = require('fs');
//esses arrays serão preechidos com informaçoes coletadas de um modo a ser definido nas proximas atividades
const array1 = [1, 3]; //contém os numeros dos comportamentos que se devem manter na dieta
const array2 = [2];    //contém os numeros dos comportamentos que não é nessessario mudar
const array3 = [4, 5]; //contém os numeros dos comportamentos que se pode mudar

function processarFrases(caminhoEntrada, caminhoSaida) {
    // Lê o arquivo de entrada
    const conteudoArquivo = fs.readFileSync(caminhoEntrada, 'utf-8');

    // Cria um mapa: número -> frase
    const mapaFrases = {};
    const regex = /(\d+)\.\s([^;]+);/g;
    let match;
    while ((match = regex.exec(conteudoArquivo)) !== null) {
        const numero = parseInt(match[1]);
        const frase = match[2].trim();
        mapaFrases[numero] = frase;
    }
    // HTML foi escolhida como estrutura intermediaria da devolutiva pela sua facil construção para fins de ser lido por um humano
    // será convertido a PDF futuramente para ser entregue como arquivo pessoal do cliente
    // Começa estrutura HTML
    let htmlSaida = `
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Frases</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; margin: 20px; }
        h2 { color: #333366; }
        p { margin-left: 20px; }
    </style>
</head>
<body>
`;

    // Seção 1
    htmlSaida += `<h2>Isto é o que você deve manter</h2>\n`;
    for (let numero of array1) {
        if (mapaFrases[numero]) {
            htmlSaida += `<p>${mapaFrases[numero]}</p>\n`;
        }
    }

    // Seção 2
    htmlSaida += `<h2>Isto é o que você talvez ainda não esteja pronto para mudar</h2>\n`;
    for (let numero of array2) {
        if (mapaFrases[numero]) {
            htmlSaida += `<p>${mapaFrases[numero]}</p>\n`;
        }
    }

    // Seção 3
    htmlSaida += `<h2>Isto é o que você pode mudar</h2>\n`;
    for (let numero of array3) {
        if (mapaFrases[numero]) {
            htmlSaida += `<p>${mapaFrases[numero]}</p>\n`;
        }
    }

    // Fecha HTML
    htmlSaida += `</body>\n</html>`;

    // Escreve no arquivo de saída
    fs.writeFileSync(caminhoSaida, htmlSaida.trim());
}

// Exemplo de uso
processarFrases('quenia perguntas.txt', 'devolutiva.html');
