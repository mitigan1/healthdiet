const express = require('express');
const app = express();
const porta = 3000;

app.use(express.json()); // Middleware para analisar JSON

app.post('/processar', (req, res) => {
    const dados = req.body;

    // Preparar três arrays
    const grupo1 = [];
    const grupo2 = [];
    const grupo3 = [];

    // Percorrer cada entrada no objeto JSON
    for (const [numeroStr, letra] of Object.entries(dados)) {
        const numero = parseInt(numeroStr);

        // Você irá editar as condições abaixo para as letras desejadas
        if (letra === 'A') {
            grupo1.push(numero);
        } else if (letra === 'B') {
            grupo2.push(numero);
        } else if (letra === 'F') {
            grupo3.push(numero);
        }
    }

    // Você pode personalizar a resposta aqui
    res.sendStatus(200); // Resposta provisória
});

app.listen(porta, () => {
    console.log(`API ouvindo em http://localhost:${porta}`);
});
